package com.example.institute_configuration

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
